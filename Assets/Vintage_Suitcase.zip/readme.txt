This work "Vintage Suitcase", is a derivative of "Suitcase" (https://sketchfab.com/models/90f9619a6ce44c949bd6df2b77cdcacd) by Santa Cruz Museum of Art and History (https://santacruzmah.org/), used under CC BY 4.0(https://creativecommons.org/licenses/by/4.0/). "Vintage Suitcase" is licensed under CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/) by romullus a.k.a LemonadeCG (https://www.cgtrader.com/lemonadecg)

Changes made: resculted raw scan, retopologized mesh to make low-poly model, baked and authored additional textures.

All restrictions to distribution of original work, applies to derivative work as well.